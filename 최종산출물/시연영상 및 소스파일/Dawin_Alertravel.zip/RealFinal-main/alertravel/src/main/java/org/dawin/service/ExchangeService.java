package org.dawin.service;

import java.util.List;

import org.dawin.domain.ExchangeDataVO;

public interface ExchangeService{
	public List<ExchangeDataVO> exchangeData();

}